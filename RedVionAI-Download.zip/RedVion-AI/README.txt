======================================
        RedVion-AI Installation & Usage Guide
======================================

1. Extract the ZIP file anywhere on your system.
2. Run "redvion.bat" by double-clicking it.
3. When the app opens, you’ll see a key icon in the upper-right corner.
   → That is where you enter your OpenAI API key.
   → RedVion uses this key to connect to the ChatGPT system.

4. IMPORTANT: You must stay ONLINE while chatting.
   Without an active internet connection, RedVion-AI cannot connect
   to the ChatGPT servers and will not respond.

5. Once the API key is added, you can start chatting instantly.

6. Do not rename, modify, or redistribute any files inside the ZIP.
   This version is optimized for Windows 10/11 standalone usage.

--------------------------------------
Developer: RedVion Technologies
Version: 1.0.0 (2025)
License: Freeware
--------------------------------------


